import os

from PIL import Image
dir='./assets/thumbnails/'
files = os.listdir(dir)


for file in (files):
    print(file)
    image_path= dir+file
    im1 = Image.open(image_path, "r")
    im1.save(f'{dir}{file[:-4]}.png')