import os
import flet as ft
import BlaApi
from flet.security import decrypt
from dotenv import load_dotenv
from pages import HomePage, LoginPage
load_dotenv()
secret_key = os.getenv('SECRET_KEY')
def main(page: ft.Page):
    
    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"
    page.fonts = {
        'roboto': 'https://raw.githubusercontent.com/google/fonts/main/apache/roboto/static/Roboto-Regular.ttf',
        'roboto_medium': 'https://raw.githubusercontent.com/google/fonts/main/apache/roboto/static/Roboto-Medium.ttf' 
    }

    api_object = None # will be set dynamically
    # we need this so that components can interact with the api.
    def login_method():
        nonlocal api_object
        username_val=page.client_storage.get('username')
        password_val=page.client_storage.get('password')
        api_object = BlaApi.Client(decrypt(username_val, secret_key), decrypt(password_val, secret_key)) # api client

    if page.client_storage.contains_key('username'):
        login_method()
        print(api_object)
    def toggle_theme(e):
        if page.theme_mode==ft.ThemeMode.DARK:
            page.theme_mode=ft.ThemeMode.LIGHT
            page.update()
            return ft.ThemeMode.LIGHT
        else:
            page.theme_mode=ft.ThemeMode.DARK
            page.update()
            return ft.ThemeMode.DARK
        
    def logout_method(e):
        def close_dlg(e):
            dlg_modal.open = False
            page.update()
        
        def logout(e):
            page.client_storage.clear()
            page.go('/login')

        dlg_modal = ft.AlertDialog(
            open=True,
            title=ft.Text("Please confirm"),
            content=ft.Text("Do you really want to logout?"),
            actions_alignment=ft.MainAxisAlignment.END,
            actions=[
                ft.TextButton("Yes", on_click=logout),
                ft.TextButton("Cancel", on_click=close_dlg)],
        )
        # add modal
        page.dialog = dlg_modal
        page.update()
    
    def route_change(e):
        print("Route change!", page.route) # for debugging
        if api_object == None:
            if page.client_storage.contains_key('username'):
                login_method()

        if not page.client_storage.contains_key('username'):
            page.theme_mode=ft.ThemeMode.LIGHT
            page.go('/login')

        if page.route == '/':
            username_val=page.client_storage.get('username')
            password_val=page.client_storage.get('password')
            page.views.append(HomePage(api_object=api_object ,toggle_theme=toggle_theme,
                        theme_mode=page.theme_mode,logout_method=logout_method))
        
        elif page.route == '/login':
            if page.client_storage.contains_key('username'):
                view_pop()
            else:
                page.views.append(LoginPage(page.client_user_agent))
        
        elif page.route == '/test':
            page.views.append(
                ft.View(
                    route='test',
                    controls=[ft.Text('this is a test route')])
            )
        page.update()
    def view_pop(e=None):
        page.views.pop()
        page.update()
        # top_view = page.views[-1] 
        # page.views.append(top_view)
        # page.go(top_view.route)

    page.title = 'Lighthouse'
    page.on_route_change=route_change
    page.on_view_pop=view_pop
    page.on_connect=route_change
    theme = ft.Theme(color_scheme_seed='#34423F')
    # page.bgcolor='#d6e3e8' # idk why this is here but it could be important
    page.theme = theme
    page.theme_mode=ft.ThemeMode.LIGHT
    page.update()
    page.go('/')


ft.app(target=main, view=None, port=8080, assets_dir='./assets')

