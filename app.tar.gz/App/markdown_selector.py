# import re

# from sample_data import diary_data

# data=diary_data[0].get('details')
# print(data)

# pattern=r"\*\*(.*?)\*\*" # matches bold markdown text
# matches=re.findall(pattern, data, re.DOTALL)

# for match in matches:
#     print("Bold Sentence:", match)

# non_bold_data = re.sub(pattern, "", data)
# non_bold_sentences = re.split(r"\n+", non_bold_data)

# for sentence in non_bold_sentences:
#     sentence = sentence.strip()
#     if sentence:
#         print("Non-bold Sentence:", sentence)


html="""<p><strong>Book: TBS</strong></p><p><strong>Unit 06: Setting up a company</strong></p><p><strong>Chapter 01: Gathering information</strong></p><p>Chapter completed; discussed all activities. 'Sharpen your skills' also covered. </p><p><br></p>"""

from html2text import html2text as h2t

print(h2t(html))
from markdownify import markdownify

# print(markdownify(html))

# from BlaApi import Client

# c = Client('03103366688', 'Mcpe03103366688_')

# data=c.get_diary_data(['3358880'])
# print(data)
# print(data[0].get('details'))