import flet as ft

class CustomInputField(ft.UserControl):
    
    def __init__(self, password: bool, hint:str, icon=None, error_text:str=None):
        
        self.input=ft.TextField(
            width=320,
            border=ft.InputBorder.UNDERLINE,
            hint_text= hint,
            text_size=16,
            hint_style= ft.TextStyle(size=12),
            max_lines=1,
            password=password,
            icon=icon,
            error_text=error_text,    
        )
        
        self.icon=ft.Icon(
            name=icon,
            size=16,
            opacity=0.85,
            color=ft.colors.ON_SURFACE_VARIANT
            )
                
        self.error_icon: ft.Icon = ft.Icon(
            name=ft.icons.ERROR_OUTLINE_OUTLINED,
            offset=ft.Offset(-1.65, -0.45),
            size=26,
            opacity=0.85,
            color=ft.colors.ERROR,
            visible=False
            )
                
        self.object = self.create_input(icon) 
        
        super().__init__()

    # we can't directly do this in the build function because we need to pass an argument (icon)
    def create_input(self, icon):
        return ft.Container(
            width=320,
            height=40,                        
            content= ft.Column(
                spacing=0,
                controls=[
                    ft.Row(
                    controls=[
                        # self.icon,
                        self.input,
                        self.error_icon
                        ]
                            
                        ),
                    ]
                ),
                
                )
        

    def build(self):
        return self.object