import flet as ft

class HomeAppBar(ft.UserControl):
    def __init__(self, toggle_theme, theme_mode, logout_method):
        
        self.toggle_theme=toggle_theme
        self.logout_method=logout_method

        # initialize theme changer icon
        if theme_mode==ft.ThemeMode.DARK:
            self.theme_icon=ft.Icon(ft.icons.LIGHT_MODE_OUTLINED)
        else:
            self.theme_icon=ft.Icon(ft.icons.DARK_MODE_OUTLINED)

        # create theme changer animator
        self.switcher = ft.AnimatedSwitcher(
            self.theme_icon,
            transition=ft.AnimatedSwitcherTransition.SCALE,
            duration=500,
            reverse_duration=100,
            switch_in_curve=ft.AnimationCurve.EASE,
            switch_out_curve=ft.AnimationCurve.EASE)
        
        super().__init__()

    def update_theme(self, e):
        # change the button's icon depending on page.ThemeMode
        dark_mode_icon=ft.Icon(ft.icons.DARK_MODE_OUTLINED)
        light_mode_icon=ft.Icon(ft.icons.LIGHT_MODE_OUTLINED)
        
        theme_mode=self.toggle_theme(e)
        if theme_mode==ft.ThemeMode.LIGHT:
            self.switcher.content=dark_mode_icon
        elif theme_mode==ft.ThemeMode.DARK:
            self.switcher.content=light_mode_icon
        
        self.switcher.update()
    


    def build(self):
        return ft.AppBar(
            # This is a place holder. in the future this should be a hamburger menu.
            leading=ft.Stack(
                controls=[
                    ft.Container(
                        margin=ft.Margin(left=20, top=18, bottom=0, right=0),
                        content=ft.Text('Lighthouse',size=22, overflow=ft.TextOverflow.VISIBLE, no_wrap=True)
                    ),
                ]
            ),

            actions=[
                # theme changer button
                ft.IconButton(icon=None, content=self.switcher, on_click=self.update_theme),
                # logout button
                ft.IconButton(icon=ft.icons.EXIT_TO_APP, on_click=self.logout_method)
            ]
        )