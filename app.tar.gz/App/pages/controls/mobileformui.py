from flet.security import encrypt
import flet as ft
import os
from BlaApi.client import Client
import asyncio
from pages.controls.custominputfield import CustomInputField

class MobileFormUI(ft.UserControl):
    def __init__(self):
        self.username=CustomInputField(False, 'Phone Number', ft.icons.PERSON_4_ROUNDED)
        self.password=CustomInputField(True, 'Password', ft.icons.LOCK_OPEN_ROUNDED)

        self.signin_button=ft.FilledButton(
            width=320,
            height=40,
            text='Sign In',
            style=ft.ButtonStyle(shape=ft.CountinuosRectangleBorder(radius=12)),
            on_click=lambda e: asyncio.run(self.update_fields(e))
        )
        self.username.input.on_submit = self.focus_password
        self.username.input.keyboard_type=ft.KeyboardType.PHONE
        self.password.input.on_submit = lambda e: asyncio.run(self.update_fields(e))

        self.secret_key=os.getenv('SECRET_KEY')
        super().__init__()

    def focus_password(self, e):
            self.password.input.focus()

    async def update_fields(self, e):  
        username_val = self.username.input.value
        password_val = self.password.input.value
        
        # if values are len 0 return error
        if len(username_val) == 0:
            self.username.input.error_text = 'Phone number cannot be empty.'
            self.username.error_icon.visible = True
            self.username.update()
        else:
            self.username.input.error_text=None
            self.username.error_icon.visible = False
            self.username.update()
            
        if len(password_val) == 0:
            self.password.input.error_text = 'Password cannot be empty.'
            self.password.error_icon.visible = True
            self.password.update()
        else:
            self.password.input.error_text=None
            self.password.error_icon.visible = False
            self.password.update()
        
        # go to next route
        if len(password_val) and len(username_val) != 0:    
            try:
                self.username.error_icon.visible=False
                self.password.error_icon.visible=False
                loading = ft.ProgressRing(scale=0.8, color=ft.colors.ON_PRIMARY)
                self.signin_button.content = loading
                self.signin_button.disabled=True
                self.signin_button.update()
                Client(username_val, password_val)
                self.page.client_storage.set('username', encrypt(username_val, self.secret_key))
                self.page.client_storage.set('password', encrypt(password_val, self.secret_key))
                self.signin_button.content = None
                self.signin_button.disabled=False
                self.page.views.clear()
                self.page.go("/")
                self.signin_button.update()
            except:
                self.username.error_icon.visible=True
                self.password.error_icon.visible=True
                self.signin_button.content=None
                self.signin_button.disabled=False
                self.username.input.error_text = 'Please check your phone number'
                self.password.input.error_text = 'Please check your password'
                self.signin_button.update()
                self.password.update()
                self.username.update()
        
    def build(self):
        return ft.Container(
            width=720,
            height=1280,
            padding=0,
            margin=-9,
            bgcolor=ft.colors.BACKGROUND, #same color as card in DesktopFormUi
            alignment= ft.alignment.center,
            content= ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Column(
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=0,
                    controls=[

                        ft.Divider(height=32, opacity=0),
                        ft.Image(
                            src=f'svg/lighthouse.svg',
                            width=72,
                            height=72
                        ),
                        ft.Divider(height=16, opacity=0,),

                        ft.Text(
                            'Sign In',
                            size=22,
                            font_family='roboto_medium',
                            color= ft.colors.ON_SURFACE
                        ),
                        ft.Divider(height=8, opacity=0),
                        ft.Text(
                            'Using your Beacon Light Academy credentials.',
                            size = 14,
                            font_family='roboto',
                            color= ft.colors.ON_SURFACE
                        ),
                        ft.Divider(height=8, opacity=0),
                    ]
                ),
                    ft.Divider(height=16, opacity=0),
                    self.username,
                    ft.Divider(height=8, opacity=0),
                    self.password,
                    ft.Divider(height=32, opacity=0),
                    self.signin_button,
                    ft.Divider(height=128,opacity=0),
                ]
            )
        )