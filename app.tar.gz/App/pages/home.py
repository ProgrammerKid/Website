import flet as ft
from pages.controls import HomeAppBar
import random
import asyncio
class ClassCard(ft.UserControl):
    def __init__(self, student_name, student_class, student_section, student_id):
        self.student_name=student_name
        self.student_class=student_class
        self.student_section=student_section
        self.student_id=student_id
        super().__init__()
    def build(self):

        return ft.Stack(
            height=140,
            controls=[
                ft.Image( 
                    f'/thumbnails/thumb_{random.randint(1, 6)}.png',
                    height=140,
                    border_radius=5,
                    fit=ft.ImageFit.COVER,
                ),

                ft.Container(
                    margin=ft.Margin(top=16, left=16, bottom=0, right=0),
                    content=ft.Text(
                        self.student_name,
                        color=ft.colors.WHITE,
                        width=220,
                        overflow=ft.TextOverflow.ELLIPSIS,
                        style=ft.TextThemeStyle.TITLE_LARGE,
                        font_family="roboto",    
                    )
                ),

                ft.Container(
                    margin=ft.Margin(top=42, left=16, right=0, bottom=0),
                    content=ft.Text(
                        f'Grade {self.student_class}',
                        style=ft.TextThemeStyle.BODY_MEDIUM,
                        color=ft.colors.WHITE,
                    )
                ),

                ft.Container(
                    margin=ft.Margin(top=112, left=16, right=0, bottom=0),
                    content=ft.Text(
                        f'Section {self.student_section}',
                        style=ft.TextThemeStyle.BODY_SMALL,
                        color=ft.colors.WHITE
                    )
                ),

                ft.ElevatedButton(
                    height=140,
                    width=565,
                    expand=True,
                    color=ft.colors.TRANSPARENT,
                    bgcolor=ft.colors.TRANSPARENT,
                    elevation=0,
                    style=ft.ButtonStyle(
                        side=ft.BorderSide(0, color=ft.colors.TRANSPARENT),
                        shape=ft.CountinuosRectangleBorder(radius=5),
                    )
                ),
            ] # Stack
        )



def pageView(api_object, toggle_theme, theme_mode, logout_method, update=None):

    print('building cards')
    app_bar = HomeAppBar(toggle_theme, theme_mode, logout_method).build()
    view = ft.View(
        route='/',
        appbar=app_bar,
        bgcolor=ft.colors.BACKGROUND,
        controls=[ft.Divider(height=0)]
    )
    print('finished building cards')
    c = api_object
    
    def build_cards():
        for student in c.students:
            student_name=student.get('student_name')
            student_class=student.get('class')
            student_section=student.get('section')
            student_id=student.get('student_id')
            view.controls.append(ClassCard(student_name, student_class, student_section, student_id))
    print('started async')
    build_cards()
    print('finished async')
    return view
    

