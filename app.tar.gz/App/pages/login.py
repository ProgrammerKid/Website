import flet as ft
from pages.controls import DesktopFormUI, MobileFormUI
import asyncio


def pageView(client_user_agent):
    if "Mobile" in client_user_agent:
        form_ui = MobileFormUI()
    else:
        form_ui = DesktopFormUI()

    return ft.View(
        route='/login',
        horizontal_alignment="center",
        vertical_alignment="center",
        controls=[form_ui],
        bgcolor='#d6e3e8'
    )