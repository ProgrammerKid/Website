diary_list = [
    {
        "id": "3358880",
        "studentId": "8426",
        "assignmentId": "73121",
        "diaryType": "fd",
        "diaryId": "73121",
        "subject": None,
        "title": "Unpaid dues!",
        "description": "9F Maymaar - Notice posted",
        "bRead": "1",
        "date": "Mon, 03/07/2023",
    },
    {
        "id": "3049213",
        "studentId": "8426",
        "assignmentId": "73121",
        "diaryType": "fd",
        "diaryId": "64980",
        "subject": None,
        "title": "Class work - 13th April",
        "description": "A class work has been posted!",
        "bRead": "1",
        "date": "Mon, 03/07/2023",
    }
]

diary_data = [
    {
        "studentId": "8426",
        "id": "3358880",
        "appDiaryId": "73121",
        "title": "Unpaid dues!",
        "details": '''
**Respected parents**\n\n\n
As per our record, some of\xa0your ward's monthly **arrears for the session 2022-23 are still remaining.**\xa0**Kindly contact to the admin office from 09:00 am\xa0 to 01:00 pm and collect the previous outstanding fee vouchers till June 2023\xa0after that you may pay it into the bank.**The Kuickpay's portal will not show you the remaining months fee data.\n\n\nIf you have already paid your ward's fee till June 2023, kindly share the paid slips on our G-mail address accounts@beaconlightacademy.edu.pk\n\n\n**Accounts Department,**\n\n\n
**Beacon Light Academy.**\n\n
''',

        "bRead": "1",
        "created": "2023-07-03 00:22:50",
        "diaryType": "fd",
        "dateDue": None,
        "attachment": None,
        "attachment2": None,
        "dateSubmitted": None,
        "subject": None,
        "currentTimestamp": "2023-07-12 14:17:33",
        "assignmentId": "73121",
        "gr_no": "12390",
        "comments": [],
    },
    {
        "studentId": "8326",
        "id": "3049213",
        "appDiaryId": "64980",
        "title": "Class work - 13th April",
        "details": '''
**Book: TBS**
**Unit 06: Setting up a company**
**Chapter 01: Gathering information**
Chapter completed; discussed all activities. 'Sharpen your skills' also covered.
''',
        "bRead": "1",
        "created": "2023-04-13 10:05:25",
        "diaryType": "cw",
        "dateDue": None,
        "attachment": None,
        "attachment2": None,
        "dateSubmitted": None,
        "subject": "ENGLISH LANGUAGE",
        "currentTimestamp": "2023-04-15 15:25:21",
        "assignmentId": "64980",
        "gr_no": "12266",
        "comments": [],
},
]
