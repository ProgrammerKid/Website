from sample_data import diary_data 

import flet as ft

class HomeworkCard(ft.UserControl):
    def __init__(self, markdown=str):
        
        self.markdown_data=markdown
        super().__init__()

    def build(self):
        return ft.Markdown(
                value=self.markdown_data,
            )

def main(page:ft.Page):
    
    # for d in diary_data:
        
    #     markdown_data=d.get('details') #get markdown from diary data
    #     page.add(HomeworkCard(
    #         markdown=markdown_data
    #     ))

    page.theme_mode=ft.ThemeMode.LIGHT

    markdown_data=diary_data[1].get('details') #get markdown from diary data
    page.add(HomeworkCard(
        markdown=markdown_data,
    ))
    

ft.app(target=main)