from winsound import Beep
from time import sleep as wait

def sound1():
    Beep(1100,130)
    Beep(800,130)
def sound2():
    Beep(800,100)
def sound3():
    Beep(250,200)
    Beep(250,200)

