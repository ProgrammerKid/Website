data = {
        "studentId": "8426",
        "id": "3358880",
        "appDiaryId": "73121",
        "title": "Unpaid dues !",
        "details": '''
**Respected parents**\n\n\n
As per our record, some of\xa0your ward's monthly **arrears for the session 2022-23 are still remaining.**\xa0**Kindly contact to the admin office from 09:00 am\xa0 to 01:00 pm and collect the previous outstanding fee vouchers till June 2023\xa0after that you may pay it into the bank.**The Kuickpay's portal will not show you the remaining months fee data.\n\n\nIf you have already paid your ward's fee till June 2023, kindly share the paid slips on our G-mail address accounts@beaconlightacademy.edu.pk\n\n\n**Accounts Department,**\n\n\n
**Beacon Light Academy.**\n\n
''',

        "bRead": "1",
        "created": "2023-07-03 00:22:50",
        "diaryType": "fd",
        "dateDue": None,
        "attachment": None,
        "attachment2": None,
        "dateSubmitted": None,
        "subject": None,
        "currentTimestamp": "2023-07-12 14:17:33",
        "assignmentId": "73121",
        "gr_no": "12390",
        "comments": [],
    }
