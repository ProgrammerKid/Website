from flet import *

def main(page: Page):
    page.window_prevent_close = True # used for save confirmation
    page.padding = 20

    dialog = AlertDialog( #save confirmation dialog
        modal=True,
        title=Text('Save Confirmation'),
        content=Text('There are some unsaved changes. Do you want to close?'),
        actions=[
            TextButton('Save and close', on_click=lambda _: save_close()),
            TextButton("Don't save", on_click=lambda _: page.window_destroy()),
            TextButton('Cancel', on_click=lambda _: cancel())
        ],
        actions_alignment='end'
    )
    page.dialog = dialog

    #appbar
    ab = AppBar(
        title=Row([
            Icon(icons.TEXT_SNIPPET_OUTLINED, size=30),
            Text('Notepad')
        ]),
        bgcolor=colors.PRIMARY_CONTAINER,
        actions=[
            IconButton(
                icons.FILE_OPEN_OUTLINED,
                icon_size=27,
                icon_color='black',
                on_click=lambda _:fp.pick_files(),
                tooltip='Open file'
            ),
            IconButton(
                icons.SAVE,
                icon_size=27,
                icon_color='black',
                on_click=lambda _:savefile(path, t.value), #pass current path and vallue of textfield
                tooltip='Save file (Ctrl+S)'
            ),
            IconButton(
                icons.CLOSE_ROUNDED,
                icon_size=27,
                icon_color='black',
                on_click=lambda _:closefile(),
                tooltip='Save and close file'
            )
        ]
    )
    page.appbar = ab #set appbar to ab

    def save_close():
        savefile(path,t.value)
        page.window_destroy()

    def cancel():
        dialog.open = False
        page.update()

    def notsaved(e):
        nonlocal saved
        saved = False

    def windowevent(e): # fired when thereis a window event
        if e.data== 'close': # if the user prssed the close button of window
            if saved == True or saved == None: # if the user has saved the files close the window direclty
                page.window_destroy()
            else:
                dialog.open = True #open save confirmation dialog
                page.update()

    page.on_window_event=windowevent

    def keyboardevent(e: KeyboardEvent): #fired when a keyboard key is pressed
        if e.ctrl == True and e.key == 'S': #if user pressed ctrl+s
            savefile(path, t.value)
    page.on_keyboard_event = keyboardevent

    def openfile(path): #this function will take path as input and return the text of the opened file
        nonlocal file
        file = open(path, 'r') #set IO file wrapper in read mode
        try: #beaasuse theres a chance the selected file is not readable
            return file.read()
        except: return 'error' #if the file is not readable

    def savefile(path, text): # this function will take text and path as input and write that text in the file of given path
        nonlocal file, saved
        try:
            saved  = True #set saved to true for save confirmation which will be added later
            file = open(path, 'w')# open file of given path in write mode
            file.write(text)# write the given text in the file
            file.close()
            t.focus()

        except: pass
    def closefile():
        nonlocal path
        ab.actions[0].disabled = False # now enable the open file button beacuse the current files is closed
        savefile(path, t.value)# save file before closing
        path = None
        t.read_only = True
        t.filled = False
        t.value = ''
        filename.value = 'Open a file to start editing'
        size_changer.visible = False # hid the slider agin beacusefile is closed
        page.update()

    def result(e: FilePickerResultEvent):
        nonlocal path
        nonlocal file

        if e.files: # check if a files has been selected
            path = e.files[0].path # set path to the path of the files selected in file picker event
            fileresult = openfile(path)

            if fileresult == 'error': #open a snack bar error if the file is ot readable
                page.snack_bar = SnackBar(
                    Text('File type not supported', text_align='center', size=20),
                    bgcolor=colors.ERROR,
                    duration=3000
                )
                page.snack_bar.open = True
                page.update()
            else: #if the file has been opened
                t.value = fileresult
                t.read_only = False
                t.filled = True
                t.focus()
                size_changer.visible = True
                ab.actions[0].disabled = True # disable the open  file button beacuse a file is already opened
                filename.value = e.files[0].name
                page.update()

    def size_changed(e):
        t.text_size = e.control.value # set the text size to the value of the control that fired the event(slider in this case)
        page.update()



    path = None # to store the path of the selected file
    file = None # to store the selected file
    saved = None # will be used later for save confirmation

    # now make a text control to show the filename
    filename = Text('Open a file to start editing', top = 15, left=20, size=20)
    page.overlay.append(filename)

    #text font changer
    size_changer = Row(
        [
            Icon(icons.FORMAT_SIZE),
            Slider(
                width=200,
                min=8, # min font size
                max=40, #max font size
                divisions=100,
                value=15, # default text size
                on_change=size_changed
            )
        ],
        top =10,
        right=0,
        visible=False,# set invisible in start beacuse no file is open
        spacing=0
    )
    page.overlay.append(size_changer)

    t = TextField( # textfiled for editing and showing text
        multiline=True,
        expand=True,
        read_only=True,
        filled=False,
        border_color='transparent',
        focused_border_color='transparent',
        text_size=15,
        on_change=notsaved # used for save confirmation
    )

    fp = FilePicker(on_result=result)
    page.overlay.append(fp)

    page.add(Row(height=30),t)

app(main)