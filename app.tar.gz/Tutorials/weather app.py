from flet import *
import json
import requests

def get_weather(city):
    link = f'http://api.weatherapi.com/v1/current.json?key=efc3acc13f9742028b895000232603&q={city}'
    r = requests.get(link)
    r = json.dumps(r.json(), indent=5)
    return r

def main(page: Page):
    page.horizontal_alignment = 'center'
    page.window_width = 400
    page.window_height = 600
    
    def button_clicked(e):
        pass

    page.appbar = AppBar(
        title=Text('Weather App'),
        bgcolor=colors.PRIMARY_CONTAINER,
        center_title=True
    )

    city = TextField(
        hint_text='Enter a city',
        width=200,
        text_size=20,
    )

    button = ElevatedButton(
        'Get Weather',
        on_click=button_clicked,
        height=60,
        style=ButtonStyle(shape=RoundedRectangleBorder(radius=6))
    )

    weather = Card(
        Column([

        ],
        width=350,
        height=400),
    )


    page.add(Row([city, button], alignment=MainAxisAlignment.CENTER), weather)

app(main)    