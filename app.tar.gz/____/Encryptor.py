import random
import string

def code(x):
  if(len(x)<3):
    x = x[::-1]
    x = random.choice(string.ascii_letters) + x + random.choice(string.ascii_letters)
  else:
    x = x[2:] + x[:2]
    x = x[::-1]
    for i in range(2):
      a = random.choice(string.ascii_letters)
      b = random.choice(string.ascii_letters)
      x = a+x+b
  return(x)
def decode(x):
  if((len(x)-2)<3):
    x = x[1:-1]
    x = x[::-1]
  else:
    x = x[2:-2]
    x = x[::-1]
    x = x[-2:] + x[:-2]
  return(x)
def code_sentence(sen):
  
  coded_sentence = ''
  words = sen.split()
  for i in words:
    coded_sentence = coded_sentence +' '+ code(i)
  return coded_sentence
def decode_sentence(sen):
    decoded_sentence = ''
    words = sen.split()
    for i in words:
      decoded_sentence = decoded_sentence +' '+ decode(i)
    return decoded_sentence
if 'name' == '__main__':
  msg = '''
  hello
  '''
  print(code_sentence(msg))
  print(decode_sentence('HphSreehamh'))