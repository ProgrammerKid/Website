import random
import os
os.system('cls')
while True :
    print("\nGuessing game")
    x = 0
    num = random.randint(1,50)

    while x < 6:
        guessed_num = int(input("\tGuess a number 1-50\n\t"))
        os.system('cls')
        if(guessed_num == num):
            print("\tCorrect number\n")
            x = 7
        elif(guessed_num > num):
            print("\tYour number is too high")
            x = x+1
        else:
            print("\tYour num is too low")
            x = x+1
    if (x == 6):
        print("You lose\n Correct number is",num)
       
   
