import random
import time
import winsound
import os
from Custom_Functions import sound1, sound2, sound3
def play(x):
    if (x == 'user'):
        u = 0 
        c = 0
        userRuns = userPlay()
        time.sleep(1.3)
        sound1()
        comRuns = comPlay()
        time.sleep(1)
        os.system('cls')
        print(f'  My points = {comRuns}')
        print(f'  Your points = {userRuns}')
        if comRuns > userRuns :
            print('\n\n  I win!')
        elif userRuns > comRuns :
            print('\n\n  You win!')
        else :
            print("\n\n  It's a tie")
        time.sleep(1)
    elif (x == 'com'):
        u = 0 
        c = 0
        comRuns = comPlay()
        time.sleep(1.3)
        sound1()
        userRuns = userPlay()
        time.sleep(1)
        os.system('cls')
        print(f'  My points = {comRuns}')
        print(f'  Your points = {userRuns}')
        if comRuns > userRuns :
            print('\n\n  I win!')
        elif userRuns > comRuns :
            print('\n\n  You win!')
        else :
            print("\n\n  It's a tie")
        time.sleep(1)
def userPlay():
    os.system('cls')
    print('  Your turn')
    time.sleep(1)
    userRuns = 0
    while True:
        os.system('cls')
        print(f'  Your turn\n  Your points = {userRuns}')
        try:
            y = int(input('\tEnter a num 1-9\n\tYou:'))
            sound2()
        except ValueError:
            continue
        if(not y in range(1,10)):
            print('\tEnter correct number')
            time.sleep(0.4)
            continue
        x = random.randint(1,9)
        print(f'\tMe: {x}')
        time.sleep(0.7)
        if x == y :
            print('\tOut')
            sound3()
            break
        else :
            userRuns += y
    return(userRuns)
def comPlay():
    os.system('cls')
    print('  My turn')
    time.sleep(1)
    comRuns = 0
    while True:
        os.system('cls')
        print(f'  My turn\n  My points = {comRuns}')
        try:
            y = int(input('\tEnter a num 1-9\n\tYou:'))
            sound2()
        except ValueError:
            continue
        if(not y in range(1,10)):
            print('\tEnter correct number')
            time.sleep(0.4)
            continue
        x = random.randint(1,9)
        print(f'\tMe: {x}')
        time.sleep(0.7)
        if x == y :
            print('\tOut')
            sound3()
            break
        else :
            comRuns += x
    return(comRuns)
while True:
    os.system('cls')
    time.sleep(0.5)
    bat_or_ball = random.choice(['bat','ball'])
    print('Welcome to the Cricket game')
    sound1()
    time.sleep(1)
    if bat_or_ball == 'bat' :
        play('user')
    elif bat_or_ball == 'ball':
        play('com')
    input('\t\n\nPress enter to play again')
    sound2()
         

