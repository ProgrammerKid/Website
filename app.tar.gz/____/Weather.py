import requests
import json
city = 'karachi'
r = requests.get(f'http://api.weatherapi.com/v1/current.json?key=efc3acc13f9742028b895000232603&q={city}')
r = json.dumps(r.json(), indent=5)

print(r)
