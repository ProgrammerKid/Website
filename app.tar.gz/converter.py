def convert_length(value, from_unit, to_unit):
    units = {
        'meter': 1,
        'kilometer': 1000,
        'centimeter': 0.01,
        'millimeter': 0.001,
        'micrometer': 1e-6,
        'nanometer': 1e-9,
        'inch': 0.0254,
        'foot': 0.3048,
        'yard': 0.9144,
        'mile': 1609.34,
        'nautical mile': 1852,
        'astronomical unit': 1.496e11,
        'light-year': 9.461e15,
    }

    if from_unit in units and to_unit in units:
        value_in_meters = value * units[from_unit]
        return round(value_in_meters / units[to_unit], 3)
    
def convert_area(value, from_unit, to_unit):
    units = {
        'square meter': 1,
        'square kilometer': 1e6,
        'square centimeter': 1e-4,
        'square millimeter': 1e-6,
        'hectare': 1e4,
        'acre': 4046.86,
        'square inch': 0.00064516,
        'square foot': 0.092903,
    }

    if from_unit in units and to_unit in units:
        value_in_square_meters = value * units[from_unit]
        return round(value_in_square_meters / units[to_unit], 3)
    
def convert_volume(value, from_unit, to_unit):
    units = {
        'cubic meter': 1,
        'liter': 0.001,
        'milliliter': 1e-6,
        'cubic inch': 1.63871e-5,
        'cubic foot': 0.0283168,
        'US gallon': 0.00378541,
        'US quart': 0.000946353,
        'US pint': 0.000473176,
        'US fluid ounce': 2.95735e-5,
    }

    if from_unit in units and to_unit in units:
        value_in_cubic_meters = value * units[from_unit]
        return round(value_in_cubic_meters / units[to_unit], 3)
    
def convert_mass(value, from_unit, to_unit):
    units = {
        'kilogram': 1,
        'gram': 0.001,
        'milligram': 1e-6,
        'microgram': 1e-9,
        'tonne': 1000,
        'ounce': 0.0283495,
        'pound': 0.453592,
        'stone': 6.35029,
    }

    if from_unit in units and to_unit in units:
        value_in_kilograms = value * units[from_unit]
        return round(value_in_kilograms / units[to_unit], 3)
    
def convert_time(value, from_unit, to_unit):
    units = {
        'second': 1,
        'millisecond': 1e-3,
        'microsecond': 1e-6,
        'nanosecond': 1e-9,
        'minute': 60,
        'hour': 3600,
        'day': 86400,
        'week': 604800,
        'year': 31557600,
    }

    if from_unit in units and to_unit in units:
        value_in_seconds = value * units[from_unit]
        return round(value_in_seconds / units[to_unit], 3)
    
def convert_speed(value, from_unit, to_unit):
    units = {
        'meter per second': 1,
        'kilometer per hour': 0.277778,
        'mile per hour': 0.44704,
        'knot': 0.514444,
    }

    if from_unit in units and to_unit in units:
        value_in_mps = value * units[from_unit]
        return round(value_in_mps / units[to_unit], 3)
    
def convert_acceleration(value, from_unit, to_unit):
    units = {
        'meter per second squared': 1,
        'gravity': 9.80665,
    }

    if from_unit in units and to_unit in units:
        value_in_mps2 = value * units[from_unit]
        return round(value_in_mps2 / units[to_unit], 3)
    
def convert_temperature(value, from_unit, to_unit):
    def celsius_to_fahrenheit(celsius):
        return (celsius * 9/5) + 32

    def fahrenheit_to_celsius(fahrenheit):
        return (fahrenheit - 32) * 5/9

    units = {
        'Celsius': 1,
        'Fahrenheit': 2,
        'Kelvin': 1,
    }

    if from_unit in units and to_unit in units:
        if from_unit == 'Celsius' and to_unit == 'Fahrenheit':
            return round(celsius_to_fahrenheit(value), 3)
        elif from_unit == 'Fahrenheit' and to_unit == 'Celsius':
            return round(fahrenheit_to_celsius(value), 3)
        else:
            return round(value, 3)
        
def convert_pressure(value, from_unit, to_unit):
    units = {
        'Pascal': 1,
        'kilopascal': 1e3,
        'megapascal': 1e6,
        'bar': 1e5,
        'millibar': 1e2,
        'atmosphere': 101325,
        'torr': 133.322,
        'psi': 6894.76,
    }

    if from_unit in units and to_unit in units:
        value_in_pascals = value * units[from_unit]
        return round(value_in_pascals / units[to_unit], 3)
    
def convert_energy(value, from_unit, to_unit):
    units = {
        'Joule': 1,
        'kilojoule': 1e3,
        'megajoule': 1e6,
        'calorie': 4.184,
        'kilocalorie': 4184,
        'electronvolt': 1.60218e-19,
        'watt-hour': 3600,
        'kilowatt-hour': 3.6e6,
    }

    if from_unit in units and to_unit in units:
        value_in_joules = value * units[from_unit]
        return round(value_in_joules / units[to_unit], 3)
    
def convert_power(value, from_unit, to_unit):
    units = {
        'Watt': 1,
        'kilowatt': 1e3,
        'megawatt': 1e6,
        'horsepower': 735.499,
    }

    if from_unit in units and to_unit in units:
        value_in_watts = value * units[from_unit]
        return round(value_in_watts / units[to_unit], 3)
    
def convert_voltage(value, from_unit, to_unit):
    units = {
        'Volt': 1,
        'kilovolt': 1e3,
    }

    if from_unit in units and to_unit in units:
        value_in_volts = value * units[from_unit]
        return round(value_in_volts / units[to_unit], 3)
    
def convert_data_size(value, from_unit, to_unit):
    units = {
        'bit': 1,
        'byte': 8,
        'kilobit': 1000,
        'kilobyte': 8000,
        'megabit': 1e6,
        'megabyte': 8e6,
        'gigabit': 1e9,
        'gigabyte': 8e9,
        'terabit': 1e12,
        'terabyte': 8e12,
        'petabit': 1e15,
        'petabyte': 8e15,
    }

    if from_unit in units and to_unit in units:
        value_in_bits = value * units[from_unit]
        return round(value_in_bits / units[to_unit], 3)