import requests
import json
def get_word_definition(word):
    url = f"https://api.dictionaryapi.dev/api/v2/entries/en/{word}"
    response = requests.get(url)
    data = json.dumps(response.json(), indent=4)
    return data

data = get_word_definition('bye')



print(data)