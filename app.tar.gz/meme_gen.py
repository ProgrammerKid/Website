import flet as ft
from flet import *
import requests
    

def main(page: ft.Page):
    # page.padding = 0
    
    page.vertical_alignment='center'
    page.horizontal_alignment='center'
    page.theme=Theme(font_family='roboto', color_scheme_seed=ft.colors.CYAN)
    page.fonts = {
        'roboto': 'https://raw.githubusercontent.com/google/fonts/main/apache/roboto/static/Roboto-Regular.ttf',
    }
    page.appbar=ft.AppBar(
        title=ft.Text('Meme Generator'),
        bgcolor=ft.colors.SURFACE_VARIANT,
        # leading=ft.Text(''),
        center_title=True,
    )
    
    # categories that correspond to a subreddit
    subreddits={
        'Wholesome': 'wholesomemes',
        'Blursed': 'blursedimages',
        'Cursed': 'holesome',
        'Programming': 'ProgrammerHumour',
        'Corny': 'Angryupvote'
    }


    def get_meme(category=None):

        # return a random meme if no category is provided
        if category:
            subreddit=subreddits.get(category) # get subreddit corresponding to provided category
            res = requests.get(f'https://meme-api.com/gimme/{subreddit}') # response
            data = res.json()
            return {
                'title': data.get('title'),
                'preview': data.get('preview')[-1],
                'url': data.get('url')
            }
        else:
            res = requests.get(f'https://meme-api.com/gimme/memes') # response
            data = res.json()
            return {
                'title': data.get('title'),
                'preview': data.get('preview')[-1],
                'url': data.get('url')
            }
        
    meme_title=ft.Container(bgcolor=ft.colors.TRANSPARENT)

    def build_meme_card(meme_category=None):
        
        meme=get_meme(meme_category)

        meme_preview=ft.Image(
            height=500,
            fit=ft.ImageFit.CONTAIN,
            src=meme.get('url') # image quality
        )
        meme_title.content=ft.Text(meme.get('title'), style=ft.TextThemeStyle.HEADLINE_SMALL)
        return ft.Card(
            height=500,
            color=ft.colors.TRANSPARENT,
            elevation=0,
            content=meme_preview
        )
    
    dropdown=ft.Dropdown(
        width=320,
        height=60,
        hint_text='Select a Category',
    )
    error_text=ft.Text('Please select a category first.', color=ft.colors.ERROR, visible=False)
    # fill dropdown menu with categories
    for category in subreddits.keys():
        dropdown.options.append(
            ft.dropdown.Option(category)
        )

    meme_card=build_meme_card()
    def update_meme(e):
        # error if category not selected
        if dropdown.value==None:
            error_text.visible=True
            page.update()
            return
        error_text.visible=False

        # update title and image
        find_meme_button.content=ft.ProgressRing(color=ft.colors.ON_PRIMARY, scale=0.8) #loading ring
        page.update()
        meme=get_meme(dropdown.value)
        meme_title.content=ft.Text(meme.get('title'), style=ft.TextThemeStyle.TITLE_LARGE)
        meme_card.content=ft.Image(
            height=600,
            fit=ft.ImageFit.CONTAIN,
            src=meme.get('url'), # image quality
        )
        find_meme_button.content=None
        page.update()

    find_meme_button=ft.FilledButton(
            width=320,
            height=40,
            text='Generate Meme',
            style=ft.ButtonStyle(shape=ft.CountinuosRectangleBorder(radius=12)),
            on_click=update_meme
    )

    # main page build
    page.add(
        meme_title,
        meme_card,
        dropdown,
        find_meme_button,
        error_text,
    )

ft.app(main)